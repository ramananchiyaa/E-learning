var Screen5 = function(data){
	var currentScreenData = data;
	var templateObj; 
	
	this.init = function(_this){
		console.log("SCREEN5 INIT CALLED");
		console.log(currentScreenData);
		
		templateObj =  _this;
		
		$("#pageTitle").html(currentScreenData.screenTitle);
		$("#screenContent").html(currentScreenData.listText);
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var curClassName = currentScreenData.audioQuePoints[i].className;
			$("."+curClassName).hide();
		}
	}
	
	this.onAudioTimeUpdate = function(curTime){
		console.log(curTime);
		
		for(var i=0;i<currentScreenData.audioQuePoints.length;i++){
			var startTime = currentScreenData.audioQuePoints[i].startTime;
			var endTime = currentScreenData.audioQuePoints[i].endTime;
			var isShown = currentScreenData.audioQuePoints[i].isShown;
			if( (startTime <= curTime) && (endTime >= curTime) && (isShown == "false") ){
				var curClassName = currentScreenData.audioQuePoints[i].className;
				$("."+curClassName).fadeIn();
				currentScreenData.audioQuePoints[i].isShown = true;
			}
		}
	}	
	
	this.onAudioEnd = function(){
		
	}
	
	this.clear = function(){
		console.log("SCREEN5 CLEAR CALLED");
	}
}