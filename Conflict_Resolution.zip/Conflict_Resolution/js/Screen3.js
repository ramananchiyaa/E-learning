var Screen3 = function(data){
	var currentScreenData = data;
	var templateObj; 
	var that = this;
	
	this.init = function(_this){
		console.log("SCREEN3 INIT CALLED");
		console.log(currentScreenData);
		
		templateObj =  _this;
		
		$(".screenTitle").html(currentScreenData.screenTitle);
		$(".screenTitle,.screencontent").fadeIn();
		
		$("#pageTitle").html(currentScreenData.screenTitle);
		$(".screenIntro").hide();
		//$(".videoArea").css({'pointer-events':'none'});
		$(".videoArea").show();
		$(".videoArea").css({'background':'url(assets/media/video/shot_04_1.png)','width':'646px','height':'434px','outline':'4px solid #6ebfe2'});
		$(".videoArea video").attr('width',646).attr('height',434).css('border','none').hide();
		
		//this.playVideo();
	}
	
	this.playVideo = function(){
		if(!isIPAD && !isAndroid){
			$(".videoArea video")[0].load();	
			$(".videoArea video")[0].play();
		}else{
			$(".videoArea video").fadeIn();	
		}
		$(".videoArea video").off('canplaythrough').on('canplaythrough',that.onCanPlayThrough);
		$(".videoArea video").off('timeupdate').on('timeupdate',that.onVideoTimeUpdate);
		$(".videoArea video").off('ended').on('ended',that.onVideoEnd);
	}
	
	this.onVideoTimeUpdate = function(){
		if( $(".videoArea video")[0].currentTime > 0 ){
			//templateObj.$contentContainer.show();
			//templateObj.$preloader.hide();
			$(".videoArea video").fadeIn();	
		}
	}
	
	this.onCanPlayThrough = function(){
		
	}
	
	this.onVideoEnd = function(){
		templateObj.playAudio('slide_03_02');
		$(".screenIntro").fadeIn();	
	}
	
	this.onAudioTimeUpdate = function(curTime){
		//console.log(curTime);
	}	
	
	this.onAudioEnd = function(curAudioName){
		if(curAudioName == 'slide_03_01'){
			this.playVideo();
		}else if(curAudioName == 'slide_03_02'){
			$(".ScreenHint").fadeIn();
			templateObj.enableNextBlink();
			//$(".nextBtn").addClass(templateObj.blinkClass);
		}
	}
	
	this.clear = function(){
		console.log("SCREEN3 CLEAR CALLED");
		$(".videoArea video")[0].pause();
		$(".videoArea video").attr('src','');
		$(".videoArea video").off('canplaythrough',that.onCanPlayThrough);
		$(".videoArea video").off('ended',that.onVideoEnd);
		$(".videoArea video").off('timeupdate',that.onVideoTimeUpdate);
	}
}