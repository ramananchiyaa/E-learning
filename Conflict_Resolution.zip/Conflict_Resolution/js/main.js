$(document).ready(function(){
			console.log('JQUERY LOADED');
			
			//$("#container").hide();
			
			$(".ScreenHint").hide();
			
			var courseConfigObj = {
				courseDataPath : "assets/data/CourseData.json",
				commonAudioPath : "assets/media/audio/",
				commonPagePath : "pages/html/",
				commonDataPath : "pages/data/",
				blinkClass : "blink_next",
								
				$screenContainer : $(".mainScreen"),
				$contentContainer : $(".screenInner"),
				$hiddenText : $("#hiddenText"),
				
				preloader:{
					$preloader : $(".preloaderCon"),
					imagesArr : imgArr,
					soundsArr : soundsArr
				},
				
				home:{
					$homeBtn : $(".homeBtn"),
					isRequired : true
				},
				
				start:{
					$startBtn : $(".StartBtn"),
					$startPageContainer : $(".landingScreen"),
					isRequired : true
				},
				
				next:{
					$nextBtn : $(".nextBtn"),
					isRequired : true
				},
				
				previous : {
					$prevBtn : $(".previousBtn"),
					isRequired : true
				},
				
				play:{
					$playBtn : $("#playPauseBtn"),
					playClass : "playBtn",
					pauseClass : "PauseBtn",
					isRequired : true
				},
				
				mute:{
					$muteBtn : $(".volumeBtn"),
					muteClass : "volumeOff",
					unMuteClass : "volumeOn",
					isRequired : true
				},
				
				transcript : {
					$transcriptBtn : $(".transcriptBtn"),
					$transcriptContainer : $(".transcriptArea"),
					$transcriptDragHandle : '',
					$transcriptContent : $(".tranContent"),
					$transcriptCloseBtn : $("#transcriptCloseBtn"),
					isRequired : true
				},
				
				clickNext : {
					$clickNext : $(".ScreenHint")
				}
			}
			
			var courseObj = new eLearningCourse(courseConfigObj);
			courseObj.init();
});	